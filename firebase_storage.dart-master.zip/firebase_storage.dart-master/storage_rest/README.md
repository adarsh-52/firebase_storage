# Storage rest Setup

**NOT SUPPORTED YET**

In `pubspec.yaml`:

```yaml
dependencies:
  tekartik_firebase_storage_rest:
    git:
      url: git://github.com/tekartik/firebase_storage.dart
      path: storage_rest
      ref: dart2
    version: '>=0.7.2'
```