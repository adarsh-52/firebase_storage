export 'src/storage_rest_impl.dart' show StorageServiceRest, storageServiceRest;
