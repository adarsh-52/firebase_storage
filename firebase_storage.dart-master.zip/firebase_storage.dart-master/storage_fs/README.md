## Setup

```yaml
dependencies:
  tekartik_firebase_storage_fs:
    git:
      url: git://github.com/tekartik/firebase_storage.dart
      path: storage_fs
      ref: dart2
    version: '>=0.4.0'
```