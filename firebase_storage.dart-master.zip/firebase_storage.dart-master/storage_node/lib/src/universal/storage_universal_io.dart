import 'package:tekartik_firebase_storage_fs/storage_fs.dart';
import 'package:tekartik_firebase_storage/storage.dart';

StorageService get storageService => storageServiceMemory;
