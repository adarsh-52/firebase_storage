import 'package:tekartik_firebase_storage/storage.dart';

StorageService get storageService =>
    throw UnsupportedError('storageService on io or node only');
