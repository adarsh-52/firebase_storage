import 'package:tekartik_firebase_storage_node/storage_node.dart';
import 'package:tekartik_firebase_storage/storage.dart';

StorageService get storageService => storageServiceNode;
