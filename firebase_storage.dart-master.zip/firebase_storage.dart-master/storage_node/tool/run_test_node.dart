import 'package:tekartik_app_node_build/app_build.dart';

Future main() async {
  await nodeRunTest();
}
