# firebase_storage_flutter

**NOT SUPPORTED YET**

## Setup

In `pubspec.yaml`:
```yaml
  tekartik_firebase_storage_flutter:
    git:
      url: git://github.com/tekartik/firebase_storage.dart
      path: storage_flutter
      ref: dart2
    version: '>=0.4.0'
```
