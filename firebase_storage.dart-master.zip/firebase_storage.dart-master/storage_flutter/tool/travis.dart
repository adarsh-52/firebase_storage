import 'package:dev_test/package.dart';

Future main() async {
  await packageRunCi('.');
}
