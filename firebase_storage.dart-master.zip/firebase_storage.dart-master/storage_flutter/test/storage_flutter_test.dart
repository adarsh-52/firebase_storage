library tekartik_firebase_storage_flutter.test.storage_flutter_test;

import 'package:flutter_test/flutter_test.dart';
import 'package:tekartik_firebase_storage/storage.dart';
import 'package:tekartik_firebase_storage_flutter/storage_flutter.dart';

void main() {
  group('firestore_flutter', () {
    test('api', () {
      // ignore: unnecessary_statements
      StorageService;
      storageServiceFlutter;
    });
  });
}
