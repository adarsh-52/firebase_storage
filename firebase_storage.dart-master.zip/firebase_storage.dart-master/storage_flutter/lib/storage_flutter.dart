import 'package:tekartik_firebase_storage/storage.dart';
import 'package:tekartik_firebase_storage_flutter/src/storage_flutter.dart'
    as storage_flutter;

StorageService get storageServiceFlutter =>
    storage_flutter.storageServiceFlutter;
