## Setup

```yaml
dependencies:
  tekartik_firebase_storage:
    git:
      url: git://github.com/tekartik/firebase_storage.dart
      path: storage
      ref: dart2
    version: '>=0.4.0'
```