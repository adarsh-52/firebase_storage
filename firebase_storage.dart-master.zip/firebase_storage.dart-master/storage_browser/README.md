## Cloud storage browsr

**NOT IMPLEMENTED**

## Test

### Setup

Copy the file `test/config.sample.yaml` as `test/config.local.yaml` with your firebase info

Run

    pub run build_runner test --fail-on-severe -- -p chrome -r expanded
    
